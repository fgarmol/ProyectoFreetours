<?php
$host = "localhost";
$user = "root";
$password = "root";
$dbname = "free_tours";

// Crear conexión
$conn = new mysqli($host, $user, $password, $dbname);

// Comprobar conexión
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Error de conexión: ' . $conn->connect_error]));
}

// Configurar la conexión para usar UTF-8
$conn->set_charset("utf8mb4");
?>
